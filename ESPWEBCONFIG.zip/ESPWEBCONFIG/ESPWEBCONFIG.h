#ifndef ESPWEBCONFIG_h
#define ESPWEBCONFIG_h
// #include <WebSerial.h>



#ifdef ESP8266
#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>
#include <flash_hal.h>


#elif defined(ESP32)
#include <WiFi.h>
#include <AsyncTCP.h>
#include <Update.h>
#else
#error "Unsupported board"
#endif

#define BUFFER_SIZE 500

#include <ESPAsyncWebServer.h>
#include "Arduino.h"
#include <LittleFS.h>
#include <FS.h>
#include <ArduinoJson.h>



extern DynamicJsonDocument json;
extern WiFiClient client;


class ESPWEBCONFIG {
public:
  ESPWEBCONFIG(uint16_t port) {
    this->port = port;
    server = new AsyncWebServer(port);
     ws = new AsyncWebSocket("/ws");
  }

  static void begin();
  static bool loop();

   void print(String m = ""){
        ws->textAll(m);
    }

    void print(const char *m){
        ws->textAll(m);
    }

    void print(char *m){
        ws->textAll(m);
    }

    void print(int m){
        ws->textAll(String(m));
    }

    void print(uint8_t m){
        ws->textAll(String(m));
    }

    void print(uint16_t m){
        ws->textAll(String(m));
    }

    void print(uint32_t m){
        ws->textAll(String(m));
    }

    void print(double m){
        ws->textAll(String(m));
    }

    void print(float m){
        ws->textAll(String(m));
    }


    // Print with New Line

    void println(String m = ""){
        ws->textAll(m+"<br>");        
    }

    void println(const char *m){
        ws->textAll(String(m)+"<br>");
    }

    void println(char *m){
        ws->textAll(String(m)+"<br>");
    }

    void println(int m){
        ws->textAll(String(m)+"<br>");
    }

    void println(uint8_t m){
        ws->textAll(String(m)+"<br>");
    }

    void println(uint16_t m){
        ws->textAll(String(m)+"<br>");
    }

    void println(uint32_t m){
        ws->textAll(String(m)+"<br>");
    }

    void println(float m){
        ws->textAll(String(m)+"<br>");
    }

    void println(double m){
        ws->textAll(String(m)+"<br>");
    }
private:
  static void onFileUpload(AsyncWebServerRequest *request, String filename, size_t index, uint8_t *data, size_t len, bool final);
  static void onEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len);
  static void handleWebSocketMessage(void *arg, uint8_t *data, size_t len);
  static void internet_settings();
  static void scanWiFiNetworks();
  static void sendWebSocketData();
  static void sorter(String num, String type);
  static void connect(const char *ssid, const char *pass);
  static void wifi();
  static void get_ipSettings();
  static void hostServer();
  static void writeConfigField(const char *fieldName, const String &fieldValue);
  static String readConfigField(const char *fieldName);
  static uint16_t port;
  static AsyncWebServer *server;
  static AsyncWebSocket *ws;
};

#endif