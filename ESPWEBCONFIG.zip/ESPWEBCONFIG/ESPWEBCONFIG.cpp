#include "Arduino.h"
#include "secrets.h"
#include "ESPWEBCONFIG.h"



DynamicJsonDocument json(2048);
WiFiClient client;


bool upload = false;
bool scan = true;
bool reboot = false;
bool upload_completed = false;

uint8_t numNetworks;


static uint8_t s_ip1, s_ip2, s_ip3, s_ip4;
static uint8_t s_gate1, s_gate2, s_gate3, s_gate4;
static uint8_t s_sub1, s_sub2, s_sub3, s_sub4;
static uint8_t s_pdns1, s_pdns2, s_pdns3, s_pdns4;
static uint8_t s_sdns1, s_sdns2, s_sdns3, s_sdns4;


const char *validUsername = SECRET_USERNAME;
const char *validPassword = SECRET_PASS;

const char *ap_SSID = Accespoint_name;
const char *ap_PASS = Accespoint_pass;


String ssid = "";
String password = "";
String componentValue;
String IP, Subnet, Gateway, Pdns, Sdns, Connection_type;

uint16_t ESPWEBCONFIG::port;
AsyncWebServer *ESPWEBCONFIG::server = nullptr;
AsyncWebSocket *ESPWEBCONFIG::ws = nullptr;


void ESPWEBCONFIG::onFileUpload(AsyncWebServerRequest *request, String filename, size_t index, uint8_t *data, size_t len, bool final) {
  String _updaterError;

  if (!upload) {
    json["UPLOAD_RESPONSE"] = "Uploading..";
    String jsonString;
    jsonString = json.as<String>();
    ws->textAll(jsonString);
    Serial.println("uploading..");
    upload = true;
  }

#ifdef ESP8266
// Serial.println("ESP8266");
  if (!index) {
    _updaterError.clear();
    Serial.printf("Update: %s\n", filename.c_str());
    Serial.println("componentValue ="+componentValue);
    int cmd = (componentValue == "filesystem") ? U_FS : U_FLASH;
    // Serial.println(cmd);
    Serial.println(".");
    Update.runAsync(true);
    size_t fsSize = ((size_t)&_FS_end - (size_t)&_FS_start);
    uint32_t maxSketchSpace = (ESP.getFreeSketchSpace() - 0x1000) & 0xFFFFF000;



    if (!Update.begin((cmd == U_FS) ? fsSize : maxSketchSpace, cmd)) {
      Serial.println("Update begin failed");
       upload_completed = true;
      return;
    }
  }
#elif defined(ESP32)
// Serial.println("ESP32");
  if (!index) {
    _updaterError.clear();
    Serial.printf("Update: %s\n", filename.c_str());
    Serial.println("componentValue ="+componentValue);
    int cmd = (componentValue == "filesystem") ? U_SPIFFS : U_FLASH;
     Serial.println(".");
    // Serial.println(cmd);
    size_t fsSize = LittleFS.totalBytes();
    uint32_t maxSketchSpace = (ESP.getFreeSketchSpace() - 0x1000) & 0xFFFFF000;



    if (!Update.begin((cmd == U_SPIFFS) ? fsSize : maxSketchSpace, cmd)) {
      Serial.println("Update begin failed");
       upload_completed = true;
      return;
    }
  }
#endif
  if (len) {
    if (Update.write(data, len) != len) {
      Serial.println("Update write failed");
       upload_completed = true;
      return;
    }
     Serial.println(".");
  }

  if (final) {
    if (!Update.end(true)) {
      Update.printError(Serial);
      Serial.println("Update end failed");
      upload_completed = true;
      return;
    }
    upload_completed = true;
    Serial.println("File uploaded successfully");
    if (componentValue == "filesystem") {
      writeConfigField("filesystem", filename.c_str());
    } else {
      writeConfigField("firmware", filename.c_str());
    }
  }
}


void ESPWEBCONFIG::sorter(String num, String type) {
  String Components[4];
  uint8_t a = 0;  // Initialize variables
  uint8_t b = 0;
  uint8_t c = 0;
  uint8_t d = 0;


  a = num.substring(0, num.indexOf(".")).toInt();
  num = num.substring(num.indexOf(".") + 1);
  b = num.substring(0, num.indexOf(".")).toInt();
  num = num.substring(num.indexOf(".") + 1);
  c = num.substring(0, num.indexOf(".")).toInt();
  d = num.substring(num.indexOf(".") + 1).toInt();


  if (type == "IP") {
    s_ip1 = a;
    s_ip2 = b;
    s_ip3 = c;
    s_ip4 = d;
  } else if (type == "SUBNET") {
    s_sub1 = a;
    s_sub2 = b;
    s_sub3 = c;
    s_sub4 = d;
  } else if (type == "GATEWAY") {
    s_gate1 = a;
    s_gate2 = b;
    s_gate3 = c;
    s_gate4 = d;
  } else if (type == "PDNS") {
    s_pdns1 = a;
    s_pdns2 = b;
    s_pdns3 = c;
    s_pdns4 = d;
  } else if (type == "SDNS") {
    s_sdns1 = a;
    s_sdns2 = b;
    s_sdns3 = c;
    s_sdns4 = d;
  }
}

void ESPWEBCONFIG::connect(const char *ssid, const char *pass) {
  unsigned long t = millis();
  WiFi.disconnect();
  if (strcmp(ssid, "") != 0) {
    WiFi.begin(ssid, pass);
    while ((WiFi.status() != WL_CONNECTED) && (millis() < t + 10000)) {
      Serial.print(".");
    }
    if (WiFi.status() == WL_CONNECTED) {
      Serial.println(" ");
      Serial.print("Connected to WiFi network: ");
      Serial.println(ssid);
      Serial.println(WiFi.localIP());
      WiFi.softAPdisconnect(ap_SSID);
      hostServer();
    }
  } else {
    Serial.println("Not Connected to WiFi network");
  }
}



void ESPWEBCONFIG::get_ipSettings() {

  IP = readConfigField("ipAddress");
  sorter(IP, "IP");
  Subnet = readConfigField("subnetMask");
  sorter(Subnet, "SUBNET");
  Gateway = readConfigField("gateway");
  sorter(Gateway, "GATEWAY");
  Pdns = readConfigField("primaryDns");
  sorter(Pdns, "PDNS");
  Sdns = readConfigField("secondaryDns");
  sorter(Sdns, "SDNS");

  Serial.println(" Connection type:" + Connection_type);
  if (Connection_type == "Static") {
    Serial.println("IP:" + IP);
    Serial.println("Gateway:" + Gateway);
    Serial.println("Subnet:" + Subnet);
    Serial.println("Pdns:" + Pdns);
    Serial.println("Sdns:" + Sdns);
  }
}

void ESPWEBCONFIG::wifi() {
  if (Connection_type == "Static") {
    get_ipSettings();
    IPAddress local_IP(s_ip1, s_ip2, s_ip3, s_ip4);  //192.168.137.199
    IPAddress gateway(s_gate1, s_gate2, s_gate3, s_gate4);
    IPAddress subnet(s_sub1, s_sub2, s_sub3, s_sub4);
    IPAddress primaryDNS(s_pdns1, s_pdns2, s_pdns3, s_pdns4);  //optional
    IPAddress secondaryDNS(s_sdns1, s_sdns2, s_sdns3, s_sdns4);
    WiFi.config(local_IP, gateway, subnet, primaryDNS, secondaryDNS);
    // WiFi.config(local_IP, gateway, subnet);
    WiFi.disconnect();
    connect(ssid.c_str(), password.c_str());
    Serial.println("");
    if (!WiFi.config(local_IP, gateway, subnet, primaryDNS, secondaryDNS)) {
      Serial.println("STA Failed to configure");
    }
    Serial.println("");
    Serial.println(WiFi.localIP());
  } else {
    connect(ssid.c_str(), password.c_str());
    Serial.println("");
    Serial.println(WiFi.localIP());
  }
}


void ESPWEBCONFIG::begin() {

  if (!LittleFS.begin()) {
    Serial.println("An Error has occurred while mounting LittleFS");
    return;
  }
  Connection_type = readConfigField("connectionType");
  ssid = readConfigField("ssid");
  password = readConfigField("password");

  Serial.println(" Connection type:" + Connection_type);
  Serial.println(" ssid:" + ssid);
  Serial.println(" password:" + password);

  wifi();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Succesfully Connected!!!");
    return;
  } else {
    Serial.println("Turning the HotSpot On");
    WiFi.softAP(ap_SSID, ap_PASS);
    hostServer();
    Serial.println(WiFi.softAPIP());
  }
}

void ESPWEBCONFIG::hostServer() {
  server->on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/login.html", "text/html");
  });
  server->on("/serial.html", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/serial.html", "text/html");
  });
  server->on("/login", HTTP_POST, [](AsyncWebServerRequest *request) {
    String username = request->arg("username");
    String password = request->arg("password");
    Serial.println("username=" + username);
    Serial.println("password=" + password);
    if (username == validUsername && password == validPassword) {
      request->send(LittleFS, "/web.html", "text/html");
    } else {
      request->send(401, "text/plain", "Invalid username or password");
    }
  });
  server->on("/style.css", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/style.css", "text/css");
  });

  server->on("/script.js", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/script.js", "text/javascript");
  });
  server->on("/eyeopen.png", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/eyeopen.png", "image/png");
  });
  server->on("/key.png", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/key.png", "image/png");
  });
  server->on("/user.png", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/user.png", "image/png");
  });
  server->on("/logo.png", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/logo.png", "image/png");
  });
  server->on("/serial.png", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/serial.png", "image/png");
  });
  server->on(
    "/upload", HTTP_POST, [](AsyncWebServerRequest *request) {
      if (Update.hasError()) {

        json["UPLOAD_RESPONSE"] = "Upload Failed  Rebooting...";
        String jsonString;
        jsonString = json.as<String>();
        ws->textAll(jsonString);
      } else {
        json["UPLOAD_RESPONSE"] = "Upload Success Rebooting...";
        String jsonString;
        jsonString = json.as<String>();
        ws->textAll(jsonString);
      }
    },
    onFileUpload);
     server->on("/type", HTTP_GET, [](AsyncWebServerRequest* request) {
    componentValue = request->arg("type");
    Serial.println("Component Value=" + componentValue);
    request->send_P(200, F("text/html"), " stat  stored");
  });
  server->begin();
  ws->onEvent(onEvent);
  server->addHandler(ws);
}


bool ESPWEBCONFIG::loop() {
  if (!upload) {
    ws->cleanupClients();
    delay(10);
    if (scan) {
      numNetworks = WiFi.scanNetworks();
      Serial.println(numNetworks);
      scan = false;
      scanWiFiNetworks();
    }
    static unsigned long lastSend = 0;
    if (millis() - lastSend >= 1000) {
      lastSend = millis();
      sendWebSocketData();
    }
    return true;
  } else if (upload && upload_completed) {
    delay(1000);
    ESP.restart();
    return false;

  } else {
    Serial.println("Something is Wrong");
    return false;
  }
}

String ESPWEBCONFIG::readConfigField(const char *fieldName) {
  // Initialize LittleFS
  if (!LittleFS.begin()) {
    Serial.println("LittleFS initialization failed!");
    return "";
  }

  // Open the file in read mode
  File configFile = LittleFS.open("/config.json", "r");
  if (!configFile) {
    Serial.println("Failed to open config file for reading!");
    return "";
  }
  // Read the JSON data from the file
  deserializeJson(json, configFile);

  // Extract the specified field
  if (json.containsKey(fieldName)) {
    return json[fieldName].as<String>();
  } else {
    return "";  // Return empty string if field doesn't exist
  }

  configFile.close();
}


void ESPWEBCONFIG::writeConfigField(const char *fieldName, const String &fieldValue) {
  // Initialize LittleFS
  if (!LittleFS.begin()) {
    Serial.println("LittleFS initialization failed!");
    return;
  }

  // Open the file in read-write mode
  File configFile = LittleFS.open("/config.json", "r+");
  if (!configFile) {
    Serial.println("Failed to open config file for writing!");
    return;
  }

  // Read the JSON data from the file

  DeserializationError error = deserializeJson(json, configFile);
  if (error) {
    Serial.print("Failed to parse JSON data from config file: ");
    Serial.println(error.f_str());
    return;
  }

  // Set the specified field
  json[fieldName] = fieldValue;

// Write the updated JSON data to the file
#ifdef ESP8266
  configFile.seek(0);
  configFile.truncate(0);
#else
  configFile.seek(0);
  configFile.write((uint8_t *)"", 0);
#endif
  serializeJson(json, configFile);

  configFile.close();
}

void ESPWEBCONFIG::onEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len) {
  switch (type) {
    case WS_EVT_CONNECT:
      Serial.printf("WebSocket client #%u connected from %s\n", client->id(), client->remoteIP().toString().c_str());
      break;
    case WS_EVT_DISCONNECT:
      Serial.printf("WebSocket client #%u disconnected\n", client->id());
      break;
    case WS_EVT_DATA:
      handleWebSocketMessage(arg, data, len);
      break;
    case WS_EVT_PONG:
      Serial.printf("WebSocket client #%u ponged\n", client->id());
      break;
    case WS_EVT_ERROR:
      Serial.printf("WebSocket client #%u error(%u): %s\n", client->id(), *((uint16_t *)arg), (char *)data);
      break;
  }
}



void ESPWEBCONFIG::handleWebSocketMessage(void *arg, uint8_t *data, size_t len) {
  AwsFrameInfo *info = (AwsFrameInfo *)arg;

  if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT) {
    // Handle text message
    data[len] = 0;
    String message = (char *)data;
    Serial.println("message =" + message);
    // Handle WebSocket message
    if (message.startsWith("{") && message.endsWith("}")) {
      // Parse JSON data
      deserializeJson(json, message);
      String command = json["command"];
      if (command == "ip_settings") {
        internet_settings();

      } else if (command == "upload_type") {
        String c = json["componentValue"];
        //  Serial.println("componentValue ="+c);
        componentValue = c;
        Serial.println("componentValue Message recived");

      } else if (command == "scan") {
        scan = true;

      } else if (command == "connect") {
        String ssid = json["ssid"];
        String password = json["password"];
        writeConfigField("ssid", ssid);
        writeConfigField("password", password);

      } else if (command == "reboot") {
        ESP.restart();

      } else if (command == "reset") {

        File jsonFile = LittleFS.open("/config.json", "r");
        deserializeJson(json, jsonFile);
        jsonFile.close();

        // Clear the contents of each field
        json["ssid"] = "";
        json["password"] = "";
        json["ipAddress"] = "";
        json["subnetMask"] = "";
        json["gateway"] = "";
        json["primaryDns"] = "";
        json["secondaryDns"] = "";
        json["connectionType"] = "";
        json["firmware"] = "";
        json["filesystem"] = "";

        // Save the updated JSON object to the file
        jsonFile = LittleFS.open("/config.json", "w");
        serializeJson(json, jsonFile);
        jsonFile.close();
        ESP.restart();

      } else {
        Serial.println("Unknown Data");
      }
    } else {
      // Web Serial Input
      Serial.println("Message Recived");
      //  ws->textAll(message+"\n");
    }
  }
}


void ESPWEBCONFIG::internet_settings() {
  String connectionType = json["connectionType"];
  String ipAddress = json["ipAddress"];
  String subnetMask = json["subnetMask"];
  String gateway = json["gateway"];
  String primaryDns = json["primaryDns"];
  String secondaryDns = json["secondaryDns"];

  writeConfigField("connectionType", connectionType);
  writeConfigField("ipAddress", ipAddress);
  writeConfigField("subnetMask", subnetMask);
  writeConfigField("gateway", gateway);
  writeConfigField("primaryDns", primaryDns);
  writeConfigField("secondaryDns", secondaryDns);

  Serial.println("Received IP settings message:");
  Serial.println("Connection Type: " + connectionType);
  if (connectionType == "Static") {
    Serial.println("IP Address: " + ipAddress);
    Serial.println("Subnet Mask: " + subnetMask);
    Serial.println("Gateway: " + gateway);
    Serial.println("Primary DNS: " + primaryDns);
    Serial.println("Secondary DNS: " + secondaryDns);
  }
}


void ESPWEBCONFIG::scanWiFiNetworks() {
  JsonArray wifiNetworks = json.createNestedArray("wifi");

  for (uint8_t i = 0; i < numNetworks; i++) {
    String ssid = WiFi.SSID(i);
    wifiNetworks.add(ssid);
    Serial.println(ssid);
  }

  String jsonString = json.as<String>();
  ws->textAll(jsonString);
  Serial.println(jsonString);
}

void ESPWEBCONFIG::sendWebSocketData() {
#ifdef ESP32
  String device = "ESP32";
#elif ESP8266
  String device = "ESP8266";
#else
  String device = "Unknown";
#endif
  // Get WiFi and device information
  String wifiname = WiFi.SSID();
  String wifiMac = WiFi.BSSIDstr();
  String deviceMac = WiFi.macAddress();
  String ipStatus = WiFi.localIP().toString();
  String wifiConnectionStatus = WiFi.status() == WL_CONNECTED ? "Connected" : "Disconnected";
  bool pingResult = client.connect("google.com", 80);
  String wifiInternetStatus = WiFi.status() == WL_CONNECTED && pingResult ? "Online" : "Offline";
  String firmwareVersion = readConfigField("firmware");      // Replace with your firmware version
  String fileSystemVersion = readConfigField("filesystem");  // Replace with your file system version

  // Create a JSON object to send to the WebSocket client
  json["device"] = device;
  json["wifiname"] = wifiname;
  json["wifiMac"] = wifiMac;
  json["deviceMac"] = deviceMac;
  json["ipStatus"] = ipStatus;
  json["wifiConnectionStatus"] = wifiConnectionStatus;
  json["wifiInternetStatus"] = wifiInternetStatus;
  json["firmwareVersion"] = firmwareVersion;
  json["fileSystemVersion"] = fileSystemVersion;

  // Send the JSON object to the WebSocket client
  String jsonString;
  jsonString = json.as<String>();
  ws->textAll(jsonString);
}
