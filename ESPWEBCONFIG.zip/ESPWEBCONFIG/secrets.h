#define SECRET_USERNAME "admin"
#define SECRET_PASS "Grapes@5M34T"
#ifdef ESP8266

#define Accespoint_name "ESP8266"
#define Accespoint_pass "123456789"

#elif defined(ESP32)

#define Accespoint_name "ESP32"
#define Accespoint_pass "123456789"

#endif